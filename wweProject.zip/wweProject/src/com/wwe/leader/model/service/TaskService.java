package com.wwe.leader.model.service;

import com.wwe.common.jdbc.JDBCTemplate;

public class TaskService {

	JDBCTemplate jdt = JDBCTemplate.getInstance();
	
}
